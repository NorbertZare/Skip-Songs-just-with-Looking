
import cv2
from picamera.array import PiRGBArray
from picamera import PiCamera
import numpy as np 
import pickle
import RPi.GPIO as GPIO
import pigpio
from time import sleep
from numpy import interp

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(14,GPIO.OUT)
GPIO.setup(15,GPIO.OUT)
GPIO.output(14,GPIO.HIGH)
GPIO.output(15,GPIO.HIGH)




camera = PiCamera()
camera.resolution = (640, 480)
rawCapture = PiRGBArray(camera, size=(640, 480))

faceCascade = cv2.CascadeClassifier("face_p.xml")


for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
	frame = frame.array
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	faces = faceCascade.detectMultiScale(gray, scaleFactor = 1.5, minNeighbors = 5)
	
	for (x, y, w, h) in faces:


                       GPIO.output(14,GPIO.LOW)
                       GPIO.output(15,GPIO.LOW)
               	       sleep(1)
                       GPIO.output(14,GPIO.HIGH)
                       GPIO.output(15,GPIO.HIGH)
                       sleep(1)

	rawCapture.truncate(0)

cv2.destroyAllWindows()
